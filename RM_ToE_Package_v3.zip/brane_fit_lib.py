
import numpy as np, math, json, csv

# ---- Cosmology constants (can be tuned) ----
T0_K = 2.7255
k_B_eV_per_K = 8.617333262e-5
T0_GeV = T0_K * k_B_eV_per_K * 1e-9
g_s0 = 3.91
g_star = 106.75
g_s_star = 106.75
Mpl_reduced_GeV = 2.435e18
HBAR_GeVs = 6.582119569e-25

def H_rad(T_GeV, gstar=g_star):
    return 1.66 * (gstar**0.5) * (T_GeV**2) / Mpl_reduced_GeV

def Hz_from_GeV(E_GeV):
    return E_GeV / HBAR_GeVs

def Tx_of_lambda(E_lambda_GeV):
    lam = E_lambda_GeV**4
    return ((60.0*lam)/(math.pi**2 * g_star))**0.25

def f0_from_T(T_GeV):
    Hstar = Hz_from_GeV(H_rad(T_GeV))
    a_ratio = (T0_GeV / T_GeV) * (g_s0 / g_s_star)**(1.0/3.0)
    return a_ratio * Hstar / (2.0*math.pi)

def f_break_of_lambda(E_lambda_GeV):
    Tx = Tx_of_lambda(E_lambda_GeV)
    return f0_from_T(Tx)

# Dark radiation mapping
_alpha = (7.0/8.0) * (4.0/11.0)**(4.0/3.0)
def C_over_rho_from_DNeff(DNeff):
    return _alpha * DNeff

def DNeff_from_C_over(C_over):
    return C_over / _alpha

# ---- Broken power-law SGWB model ----
def omega_gw_broken(f, f_br, n1, n2, Omega0):
    """
    Omega_GW(f) = Omega0*(f/f_br)^n1 for f < f_br; = Omega0*(f/f_br)^n2 for f >= f_br.
    f: Hz (array), f_br: Hz, exponents n1,n2, normalization Omega0.
    """
    f = np.asarray(f)
    below = f < f_br
    out = np.empty_like(f, dtype=float)
    with np.errstate(divide='ignore'):
        out[below]  = Omega0 * (f[below]/f_br)**(n1)
        out[~below] = Omega0 * (f[~below]/f_br)**(n2)
    return out

# ---- Likelihood pieces ----
def like_pta_spectrum(f, omega_obs, sigma_obs, f_br, n1, n2, Omega0):
    model = omega_gw_broken(f, f_br, n1, n2, Omega0)
    chi2 = np.sum(((omega_obs - model)/sigma_obs)**2)
    return -0.5*chi2

def like_lisa_upperlimit(f, omega_model, omega_noise_floor):
    """
    Simple conservative 'exclusion' style: penalize points where model >> noise.
    This is a placeholder; replace with your LISA likelihood when available.
    """
    ratio = omega_model / np.maximum(omega_noise_floor, 1e-99)
    penalty = np.sum(np.clip(ratio - 1.0, 0, None)**2)
    return -0.5*penalty

def like_delta_neff(DNeff, mean, sigma):
    return -0.5*((DNeff - mean)/sigma)**2

# ---- Data loaders for CSV/JSON ----
def load_pta_csv(path):
    """
    CSV columns: f_Hz, omega_gw, sigma
    """
    data = np.genfromtxt(path, delimiter=',', names=True)
    return data['f_Hz'], data['omega_gw'], data['sigma']

def load_lisa_csv(path):
    """
    CSV columns: f_Hz, omega_noise_floor
    """
    data = np.genfromtxt(path, delimiter=',', names=True)
    return data['f_Hz'], data['omega_noise_floor']

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)
