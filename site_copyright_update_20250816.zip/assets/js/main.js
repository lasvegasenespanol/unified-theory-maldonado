// Minimal site JS placeholder
console.debug('site loaded');
