Unified Brane-Cosmology — DataKit v2 (Real Data)

Place your REAL data files in this folder with the following names:
- pta_spectrum_REAL.csv          # NANOGrav/EPTA/IPTA binned spectrum (f_Hz, OmegaGW, sigma_OmegaGW)
- cmb_bbn_priors_REAL.csv        # Gaussian prior on DeltaNeff: columns (DeltaNeff_mean, DeltaNeff_sigma)
- lisa_curve_REAL.csv (optional) # Upper-limit or sensitivity curve (f_Hz, OmegaGW_upperlimit)

Column headers must match exactly. Units: f in Hz, OmegaGW dimensionless.

Where to obtain:
- PTA: use released points from NANOGrav 15yr / EPTA DR2 / IPTA combined products.
- CMB/BBN: use Planck 2018+BAO Gaussian prior on N_eff (e.g., mean ~ 2.99, sigma ~ 0.17) or your latest combined constraint.
- LISA: generate a sensitivity curve from Robson et al. (2019) or use official curve samples.

Run:
1) Open run_minimal_fit_REAL.ipynb in Jupyter.
2) Ensure the three CSVs exist (or comment out LISA if not used).
3) Run all cells. Outputs: bestfit_real.json, posterior_plots.png, pta_fit_real.png, and Results_RealData.pdf.

Note: This is a minimal, fast likelihood. For publication, swap in the official PTA likelihood and a realistic DeltaNeff mapping.
