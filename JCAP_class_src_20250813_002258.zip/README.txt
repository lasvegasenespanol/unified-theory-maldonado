JCAP class source — Aug 13, 2025 (UTC)
Compile with: pdflatex main; bibtex main; pdflatex main; pdflatex main.
Requires jcap.cls in the working directory or installed.
