REVTeX 4.2 (PRD) — Aug 13, 2025 (UTC)
Compile with: pdflatex main; bibtex main; pdflatex main; pdflatex main.
Requires revtex4-2 and standard packages.
