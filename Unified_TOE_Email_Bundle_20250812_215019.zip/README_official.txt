Updated with official NANOGrav 15-yr KDE free-spectrum — converted on Aug 12, 2025 (UTC).
Two-Pager and master PDF appended with official-data plots.
Planck-2018 prior used: N_eff = 2.99 ± 0.17 (BAO); parameter is ΔN_eff ≡ N_eff − 3.046.
KDE set used: 30f_fs{cp}_ceffyl.
