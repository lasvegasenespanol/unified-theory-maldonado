Data & Repro Pack — Demo (Maldonado, 2025-08-14)

Purpose
-------
Minimal, machine-readable files to reproduce the demo figures used in the brane-world test:
(1) a PTA broken-power-law fit with a spectral break f_br, and
(2) a LISA sensitivity overlay for context.

Files
-----
- PTA_public_anchor_demo.csv
- ESA_RCL2019_4yr_instrument_ONLY_demo.csv
- ESA_RCL2019_4yr_instrument_PLUS_confusion_demo.csv
- ESA_RCL2019_10yr_instrument_ONLY_demo.csv
- ESA_RCL2019_10yr_instrument_PLUS_confusion_demo.csv
- BestFit_with_uncertainties_demo.json
- PTA_fit_brokenPL_demo.png
- PTA_fit_with_LISA_demo.png
- Results_TwoPager_DEMO.pdf
- reproduce_posteriors.py
- columns_and_units.txt

How to use
----------
1) Open reproduce_posteriors.py and run it (Python 3 + numpy + pandas + matplotlib).
2) It will read the PTA CSV, fit a broken power law, print the inferred f_br, and
   save plots + a small JSON of best-fit parameters.
3) Swap in official PTA/LISA CSVs any time to regenerate publication-grade overlays.

Notes
-----
- These are demo numbers and shapes (placeholders) to exercise the pipeline.
- For official analyses, replace the PTA CSV with exported_pta_spectrum.csv derived
  from NANOGrav/IPTA KDE free-spectrum packages and use official LISA sensitivity curves.
