#!/usr/bin/env python3
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def fit_broken_power_log(x, y, min_pts=6):
    best = None
    for i in range(min_pts, len(x)-min_pts):
        x1, y1 = x[:i], y[:i]
        x2, y2 = x[i:], y[i:]
        m1, b1 = np.polyfit(x1, y1, 1)
        m2, b2 = np.polyfit(x2, y2, 1)
        yhat = np.concatenate([m1*x1 + b1, m2*x2 + b2])
        rss = np.sum((y - yhat)**2)
        if best is None or rss < best["rss"]:
            best = {"i": i, "m1": m1, "b1": b1, "m2": m2, "b2": b2, "rss": rss}
    xb = (best["b2"] - best["b1"]) / (best["m1"] - best["m2"])
    return best, xb

def main():
    base = Path(".")
    pta_csv = base / "PTA_public_anchor_demo.csv"
    df = pd.read_csv(pta_csv)
    f = df["freq_Hz"].values
    y = df["log10rho_median"].values
    x = np.log10(f)
    best, xb = fit_broken_power_log(x, y)
    f_br = 10**xb
    print(f"Estimated break frequency f_br ≈ {f_br:.3e} Hz")
    res = {"f_br_Hz": float(f_br), "slope_low": float(best['m1']), "slope_high": float(best['m2']), "rss": float(best["rss"])}
    with open("BestFit_with_uncertainties_demo.json", "w") as fh:
        json.dump(res, fh, indent=2)

    # Quick plot
    x1, y1 = x[:best["i"]], best["m1"]*x[:best["i"]] + best["b1"]
    x2, y2 = x[best["i"]:], best["m2"]*x[best["i"]:] + best["b2"]
    plt.figure()
    plt.scatter(f, y, s=16, label="PTA median (demo)")
    plt.plot(10**x1, y1, label="Fit (low-f)", linewidth=2)
    plt.plot(10**x2, y2, label="Fit (high-f)", linewidth=2)
    plt.axvline(f_br, linestyle="--", label=f"f_br ≈ {f_br:.2e} Hz")
    plt.xscale("log")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("log10 rho (demo units)")
    plt.legend()
    plt.tight_layout()
    plt.savefig("PTA_fit_brokenPL_demo.png", dpi=180)

if __name__ == "__main__":
    main()
