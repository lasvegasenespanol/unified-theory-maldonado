README_arXiv.txt
================

Title: Data and Repro Pack for "A testable brane-world unification: one parameter links a GW spectral break and Delta N_eff" (Maldonado, 2025)
Version: v1.0.0
Generated: 2025-08-14 20:27 UTC

Purpose
-------
This Supplemental Material (SM) contains machine-readable files to reproduce the figures and key checks in the associated manuscript.
It provides: (i) PTA spectrum CSV(s) used for a broken-power-law fit and GW break-frequency preview, (ii) LISA sensitivity CSV(s) in
an ESA-style column format for overlays, (iii) a compact two-page results PDF, (iv) a tiny JSON with illustrative best-fit numbers,
and (v) a brief README describing columns and reproduction steps.

Contents (typical)
------------------
- PTA CSV (example names):
    exported_pta_spectrum_DEMO_30f.csv
    exported_pta_spectrum_CP_30f.csv
    exported_pta_spectrum_HD_30f.csv
- LISA CSV (ESA-style columns):
    LISA_RCL2019_4yr_instrument_ONLY_DEMO.csv
    LISA_RCL2019_4yr_instrument_PLUS_confusion_DEMO.csv
    LISA_RCL2019_10yr_instrument_ONLY_DEMO.csv
    LISA_RCL2019_10yr_instrument_PLUS_confusion_DEMO.csv
- Planck 2018 prior (JSON): CMB_Planck2018_DeltaNeff_prior.json
- Best-fit example (JSON): BestFit_with_uncertainties.json
- Figure (PNG): PTA_fit_with_LISA_demo.png
- Two-Pager (PDF): Results_TwoPager_DEMO_REFRESH.pdf
- Column schema: columns_and_units.txt (plain text)

Column schema (required)
------------------------
PTA CSV columns:
    freq_Hz            # frequency in Hz
    log10rho_median    # median log10 rho(f)
    log10rho_p16       # 16th percentile
    log10rho_p84       # 84th percentile

LISA CSV columns:
    f_Hz               # frequency in Hz
    Sn_1_per_Hz        # one-sided strain noise PSD in 1/Hz
    label              # short text label, ASCII only

How to reproduce (minimal)
--------------------------
1) Load the PTA CSV and fit a broken power law in log10 rho(f) with one break frequency f_br.
2) Overlay any LISA CSV to provide visual context for space-based sensitivity.
3) Compare to the supplied Two-Pager figure and the small JSON of illustrative best-fit values.

Key equations (ASCII/mathtext)
------------------------------
Grand equation (flat FRW, k=0, with rho^2 and dark-radiation terms):
    H^2 = (8*pi*G/3) * rho * (1 + rho/(2*lambda)) + Lambda4/3 + C/a^4

Two test relations (falsifiability):
    f_br(lambda) proportional to lambda^(1/4)
    C / rho_gamma,0 = (7/8) * (4/11)^(4/3) * Delta N_eff

License
-------
Unless stated otherwise in the record, this SM is released under CC BY 4.0.

Contact
-------
Ricardo Maldonado — sales@rank.vegas
