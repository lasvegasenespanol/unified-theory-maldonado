JCAP-like source (lite) — Aug 13, 2025 (UTC)
Compile with: pdflatex main.
If you have jcap.cls, change \documentclass to jcap.
