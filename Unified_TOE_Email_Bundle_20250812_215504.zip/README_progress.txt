Updated pack — Aug 12, 2025 (UTC)
- Unified_Theory_SEND_ONE_FILE_FINAL_*.pdf now includes: Criteria v2, Compactification options, GW Context (PTA→LISA), and OFFICIAL Two-Pager.
- Official PTA CSV provenance: KDE set converted from the NANOGrav 15-yr Zenodo package you uploaded.
- Planck-2018 prior used: N_eff = 2.99 ± 0.17 (BAO), applied as ΔN_eff = N_eff − 3.046.
