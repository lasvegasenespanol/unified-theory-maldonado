Supplemental Material: data & reproduction pack with PTA spectrum (CSV), LISA sensitivity (CSV, ESA-style),
Planck 2018 ΔN_eff prior (JSON), an example best-fit (JSON), and a minimal script to regenerate the quick-look plots.
A single λ must simultaneously place the GW spectral break in PTA→LISA context and satisfy ΔN_eff bounds.
