Schema, quick-run command, and notes.
