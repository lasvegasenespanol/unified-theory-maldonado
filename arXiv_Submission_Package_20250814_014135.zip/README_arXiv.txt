arXiv Submission — Ready-to-Upload Package
=========================================
Generated (UTC): 2025-08-14 01:41

FILES IN THIS ZIP
-----------------
- Manuscript (main PDF): Submission_PRL_style_20250814_010932.pdf
- Figures: Results_TwoPager_REALDATA_LISA_OFFICIALFORMAT_SWAP_20250814_012230.pdf
- LISA sensitivity CSVs (official-format headers): ['ESA_OFFICIAL_FORMAT_TEMPLATE_4yr_instrument_only.csv', 'ESA_OFFICIAL_FORMAT_TEMPLATE_10yr_instrument_plus_confusion.csv', 'ESA_RCL2019_4yr_instrument_ONLY_20250814_010448.csv', 'ESA_RCL2019_4yr_instrument_PLUS_confusion_20250814_010448.csv', 'ESA_RCL2019_10yr_instrument_ONLY_20250814_010448.csv', 'ESA_RCL2019_10yr_instrument_PLUS_confusion_20250814_010448.csv']
- PTA spectrum CSV (public anchor): exported_pta_spectrum_HD_30f.csv
- Metadata: arXiv_metadata.txt (copy/paste title/abstract/categories/license)
- HOWTO: arXiv_UPLOAD_STEPS.txt (step-by-step)

RECOMMENDED CATEGORIES
----------------------
Primary: hep-th
Cross-lists: gr-qc, astro-ph.CO

LICENSE
-------
CC BY 4.0 (recommended open license unless journal mandates otherwise).

NOTES
-----
• Keep the main manuscript science-only. Press pages and cover letters should remain out of the main PDF.
• Upload the figure PDF and CSVs as “Ancillary files” (or “Supplemental files”).

Contact: Ricardo Maldonado — sales@rank.vegas
