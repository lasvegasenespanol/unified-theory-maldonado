Repro Pack (MIN): PTA CSV + toy posterior script and figures. Replace with official KDE export for publication.
