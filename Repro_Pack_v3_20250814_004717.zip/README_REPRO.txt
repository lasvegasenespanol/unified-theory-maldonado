README_REPRO (v3)
This zip reproduces the broken power-law PTA fit and exports best-fit JSON.

Quick start (60 seconds):
python reproduce_posteriors.py --pta exported_pta_spectrum_HD_30f.csv --out results/

Files:
- exported_pta_spectrum_HD_30f.csv  (from NANOGrav KDE free-spectrum HD-30f)
- reproduce_posteriors.py           (fits model; writes best_fit_REALDATA.json)
- best_fit_REALDATA.json            (numbers from the refreshed pass)
- CITATION.txt                      (how to cite)
