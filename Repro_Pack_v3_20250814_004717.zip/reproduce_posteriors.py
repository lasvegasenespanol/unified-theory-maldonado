#!/usr/bin/env python3
import json, argparse
import numpy as np, pandas as pd

def fit(pta_csv):
    pta = pd.read_csv(pta_csv)
    f = pta['freq_Hz'].values
    y_med = pta['log10rho_median'].values
    y_lo = pta['log10rho_p16'].values
    y_hi = pta['log10rho_p84'].values
    sigma = 0.5*(y_hi - y_lo); sigma[sigma<=1e-6]=np.median(sigma[sigma>1e-6]) if np.any(sigma>1e-6) else 0.2
    logf = np.log10(f); w = 1.0/(sigma**2)
    def best_b0(L,a1,a2):
        m = np.where(logf<L, a1*(logf-L), a2*(logf-L))
        return np.sum(w*(y_med - m))/np.sum(w)
    def chi2(L,a1,a2):
        b0 = best_b0(L,a1,a2)
        ymod = np.where(logf<L, b0+a1*(logf-L), b0+a2*(logf-L))
        return np.sum(((y_med-ymod)/sigma)**2), b0
    best={'chi2':np.inf}
    for L in np.linspace(np.log10(f.min()*1.2), np.log10(f.max()/1.2), 100):
        for a1 in np.linspace(-0.5,3.0,60):
            for a2 in np.linspace(-6.0,0.0,60):
                c,b0=chi2(L,a1,a2)
                if c<best['chi2']:
                    best={'chi2':c,'logf_br':float(L),'a1':float(a1),'a2':float(a2),'b0':float(b0)}
    f_br=10**best['logf_br']; f0=1e-8; lam=(f_br/f0)**4
    return {'f_br_Hz':float(f_br),'a1':best['a1'],'a2':best['a2'],'lambda_scaled':float(lam),'chi2_min':float(best['chi2'])}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--pta',required=True); ap.add_argument('--out',default='results')
    A=ap.parse_args()
    import os; os.makedirs(A.out, exist_ok=True)
    res=fit(A.pta); 
    with open(os.path.join(A.out,'best_fit_REALDATA.json'),'w') as fh: json.dump(res, fh, indent=2)
    print('Wrote', os.path.join(A.out,'best_fit_REALDATA.json'))
