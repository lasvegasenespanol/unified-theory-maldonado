Unified Brane-Cosmology — DataKit v1

Files:
- pta_spectrum_template.csv         (replace with real PTA spectrum)
- lisa_curve_template.csv           (optional: add LISA/upper-limit curve)
- cmb_bbn_priors_template.csv       (Delta N_eff prior)
- run_minimal_fit.ipynb             (notebook to run a toy joint fit)
- bestfit_demo.json (generated)     (best-fit parameters from the toy run)
- pta_fit_demo.png (generated)      (model vs PTA points)

How to run:
1) Open run_minimal_fit.ipynb in Jupyter.
2) Replace the *template* CSVs with real data (same column headers).
3) Run all cells. The notebook writes bestfit_demo.json and figures.
4) Copy outputs into your paper / results brief.

Note: The likelihood is intentionally simple. For publication, extend it to the
official PTA likelihood + a more realistic Delta N_eff mapping and priors.
